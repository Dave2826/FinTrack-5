import strawberry

from enum import Enum
from decimal import Decimal
from datetime import date, datetime

from strawberry.types import Info

from services.balance_service import (
    account_balance_service,
    general_balance_service,
)

from services.account_service import (
    create_account_service,
    get_account_service,
    list_accounts_service,
)

from services.concept_service import (
    create_concept_service,
    get_concept_service,
    list_concepts_service,
)

from services.account_concept_service import (
    assign_concept_to_account,
    get_account_concepts_service,
    remove_concept_from_account,
)

from services.transaction_service import (
    create_transaction_service,
    list_transactions_service,
    delete_transaction_service,
)

from services.auth_service import authenticate_user

from services.role_service import (
    create_role_service,
    deactivate_role_service,
    list_roles_service,
)

from services.permission_service import (
    create_permission_service,
    list_permissions_service,
)

from services.role_permission_service import (
    assign_permission_to_role_service,
    remove_permission_from_role_service,
    list_role_permissions_service,
    permission_catalog_service,
    preview_role_permissions_service,
    set_role_permissions_service,
)

from services.company_user_service import (
    create_company_user_service,
    deactivate_company_user_service,
    assign_role_service,
    list_company_users_service,
)

from models.account import Account as AccountModel
from models.account import AccountType as AccountTypeModel

from models.concept import Concept as ConceptModel
from models.concept import ConceptType as ConceptTypeModel

from models.account_concept import AccountConcept as AccountConceptModel

from models.transaction import Transaction as TransactionModel
from models.transaction import TransactionType as TransactionTypeModel

from models.role import Role as RoleModel

from models.permission import Permission as PermissionModel

from models.role_permission import RolePermission as RolePermissionModel

from models.company_user_role import CompanyUserRole as CompanyUserRoleModel

from models.company_user import CompanyUser as CompanyUserModel

from models.user import User as UserModel


@strawberry.enum
class AccountType(Enum):
    DEBIT = "DEBIT"
    CREDIT = "CREDIT"
    CASH = "CASH"
    SAVINGS = "SAVINGS"
    INVESTMENT = "INVESTMENT"
    WALLET = "WALLET"
    OTHER = "OTHER"


@strawberry.enum
class ConceptType(Enum):
    INCOME = "INCOME"
    EXPENSE = "EXPENSE"


@strawberry.enum
class TransactionType(Enum):
    INCOME = "INCOME"
    EXPENSE = "EXPENSE"


@strawberry.enum
class PermissionResource(Enum):
    COMPANY_USERS = "COMPANY_USERS"
    ACCOUNTS = "ACCOUNTS"
    CONCEPTS = "CONCEPTS"
    TRANSACTIONS = "TRANSACTIONS"
    ROLES = "ROLES"


PREFIJOS_RECURSO: dict[PermissionResource, str] = {
    PermissionResource.COMPANY_USERS: "company.users.",
    PermissionResource.ACCOUNTS: "accounts.",
    PermissionResource.CONCEPTS: "concepts.",
    PermissionResource.TRANSACTIONS: "transactions.",
    PermissionResource.ROLES: "roles.",
}


@strawberry.type
class Account:
    id: int
    company_id: int
    account_type: AccountType
    name: str
    bank_name: str | None
    account_number: str | None
    clabe: str | None
    card_last_digits: str | None
    short_description: str | None
    long_description: str | None
    is_active: bool

    @staticmethod
    def from_model(account: AccountModel):
        return Account(
            id=account.id,
            company_id=account.company_id,
            account_type=AccountType(account.account_type.value),
            name=account.name,
            bank_name=account.bank_name,
            account_number=account.account_number,
            clabe=account.clabe,
            card_last_digits=account.card_last_digits,
            short_description=account.short_description,
            long_description=account.long_description,
            is_active=account.is_active,
        )


@strawberry.type
class Concept:
    id: int
    company_id: int
    concept_type: ConceptType
    name: str
    short_description: str | None
    long_description: str | None
    is_active: bool

    @staticmethod
    def from_model(concept: ConceptModel):
        return Concept(
            id=concept.id,
            company_id=concept.company_id,
            concept_type=ConceptType(concept.concept_type.value),
            name=concept.name,
            short_description=concept.short_description,
            long_description=concept.long_description,
            is_active=concept.is_active,
        )


@strawberry.type
class AccountConcept:
    id: int
    account_id: int
    concept_id: int
    is_active: bool

    @staticmethod
    def from_model(relation: AccountConceptModel):
        return AccountConcept(
            id=relation.id,
            account_id=relation.account_id,
            concept_id=relation.concept_id,
            is_active=relation.is_active,
        )


@strawberry.type
class Transaction:
    id: int
    account_id: int
    concept_id: int
    transaction_type: TransactionType
    amount: Decimal
    transaction_date: datetime
    captured_at: datetime
    captured_by: int
    short_description: str | None
    long_description: str | None
    is_active: bool

    @staticmethod
    def from_model(transaction: TransactionModel):
        return Transaction(
            id=transaction.id,
            account_id=transaction.account_id,
            concept_id=transaction.concept_id,
            transaction_type=TransactionType(
                transaction.transaction_type.value
            ),
            amount=transaction.amount,
            transaction_date=transaction.transaction_date,
            captured_at=transaction.captured_at,
            captured_by=transaction.captured_by,
            short_description=transaction.short_description,
            long_description=transaction.long_description,
            is_active=transaction.is_active,
        )


@strawberry.type
class AccountBalance:
    account_id: strawberry.ID
    account_name: str
    is_active: bool
    opening_balance: Decimal
    total_income: Decimal
    total_expense: Decimal
    profit: Decimal
    closing_balance: Decimal
    is_in_red: bool
    currency: str

    @staticmethod
    def from_result(balance):
        return AccountBalance(
            account_id=strawberry.ID(str(balance.account_id)),
            account_name=balance.account_name,
            is_active=balance.is_active,
            opening_balance=balance.opening_balance,
            total_income=balance.total_income,
            total_expense=balance.total_expense,
            profit=balance.profit,
            closing_balance=balance.closing_balance,
            is_in_red=balance.is_in_red,
            currency=balance.currency,
        )


@strawberry.type
class GeneralBalance:
    company_id: strawberry.ID
    from_date: date
    to_date: date
    opening_balance: Decimal
    total_income: Decimal
    total_expense: Decimal
    profit: Decimal
    closing_balance: Decimal
    accounts_in_red: int
    is_in_red: bool
    currency: str
    accounts: list[AccountBalance]

    @staticmethod
    def from_result(balance):
        return GeneralBalance(
            company_id=strawberry.ID(str(balance.company_id)),
            from_date=balance.from_date,
            to_date=balance.to_date,
            opening_balance=balance.opening_balance,
            total_income=balance.total_income,
            total_expense=balance.total_expense,
            profit=balance.profit,
            closing_balance=balance.closing_balance,
            accounts_in_red=balance.accounts_in_red,
            is_in_red=balance.is_in_red,
            currency=balance.currency,
            accounts=[
                AccountBalance.from_result(cuenta)
                for cuenta in balance.accounts
            ],
        )


@strawberry.type
class Role:
    id: int
    code: str
    name: str
    description: str | None
    is_active: bool

    @staticmethod
    def from_model(role: RoleModel):
        return Role(
            id=role.id,
            code=role.code,
            name=role.name,
            description=role.description,
            is_active=role.is_active,
        )


@strawberry.type
class Permission:
    id: int
    code: str
    name: str
    description: str | None
    is_active: bool

    @staticmethod
    def from_model(permission: PermissionModel):
        return Permission(
            id=permission.id,
            code=permission.code,
            name=permission.name,
            description=permission.description,
            is_active=permission.is_active,
        )


@strawberry.type
class RolePermission:
    id: int
    role_id: int
    permission_id: int
    is_active: bool

    @staticmethod
    def from_model(relation: RolePermissionModel):
        return RolePermission(
            id=relation.id,
            role_id=relation.role_id,
            permission_id=relation.permission_id,
            is_active=relation.is_active,
        )


@strawberry.type
class RolePermissionPlan:
    role: Role
    current: list[Permission]
    to_activate: list[Permission]
    to_deactivate: list[Permission]
    unchanged: list[Permission]
    final_count: int


@strawberry.type
class RolePermissionUpdate:
    role: Role
    activated: list[Permission]
    deactivated: list[Permission]
    unchanged: list[Permission]
    final_count: int
    changed: bool


@strawberry.type
class CompanyUserRole:
    id: int
    company_user_id: int
    role_id: int
    is_active: bool

    @staticmethod
    def from_model(relation: CompanyUserRoleModel):
        return CompanyUserRole(
            id=relation.id,
            company_user_id=relation.company_user_id,
            role_id=relation.role_id,
            is_active=relation.is_active,
        )


@strawberry.type
class CompanyUser:
    id: int
    company_id: int
    user_id: int
    is_admin: bool
    is_active: bool
    joined_at: datetime

    @staticmethod
    def from_model(company_user: CompanyUserModel):
        return CompanyUser(
            id=company_user.id,
            company_id=company_user.company_id,
            user_id=company_user.user_id,
            is_admin=company_user.is_admin,
            is_active=company_user.is_active,
            joined_at=company_user.joined_at,
        )


@strawberry.input
class CreateAccountInput:
    company_id: int
    account_type: AccountType
    name: str
    bank_name: str | None = None
    account_number: str | None = None
    clabe: str | None = None
    card_last_digits: str | None = None
    short_description: str | None = None
    long_description: str | None = None


@strawberry.input
class CreateConceptInput:
    company_id: int
    concept_type: ConceptType
    name: str
    short_description: str | None = None
    long_description: str | None = None


@strawberry.input
class AssignConceptToAccountInput:
    account_id: int
    concept_id: int


@strawberry.input
class CreateTransactionInput:
    account_id: int
    concept_id: int
    transaction_type: TransactionType
    amount: Decimal
    transaction_date: datetime | None = None
    short_description: str | None = None
    long_description: str | None = None


@strawberry.input
class LoginInput:
    email: str
    password: str


@strawberry.type
class User:
    id: int
    name: str
    email: str

    @staticmethod
    def from_model(user: UserModel):
        return User(
            id=user.id,
            name=user.name,
            email=user.email,
        )


@strawberry.type
class AuthPayload:
    token: str
    token_type: str
    user: User


@strawberry.input
class CreateRoleInput:
    code: str
    name: str
    description: str | None = None


@strawberry.input
class CreatePermissionInput:
    code: str
    name: str
    description: str | None = None


@strawberry.input
class AssignPermissionToRoleInput:
    role_id: int
    permission_id: int


@strawberry.input
class CreateCompanyUserInput:
    company_id: int
    user_id: int
    is_admin: bool = False


@strawberry.input
class AssignRoleInput:
    company_user_id: int
    role_id: int


@strawberry.input
class SetRolePermissionsInput:
    role_id: strawberry.ID
    permission_ids: list[strawberry.ID]


def _a_entero(valor, etiqueta: str) -> int:
    try:
        return int(valor)
    except (TypeError, ValueError):
        raise ValueError(
            f"{etiqueta} no es un ID valido: {valor}"
        )


def _identidad(info: Info) -> CompanyUserModel:
    """Identidad autenticada de la petición (membresía del token)."""

    company_user = info.context.get("company_user")

    if company_user is None:
        raise ValueError(
            info.context.get("auth_error") or "Usuario no autenticado"
        )

    return company_user


def _resolver_list_roles(info: Info) -> list[Role]:

    identidad = _identidad(info)

    db = info.context["db"]

    roles = list_roles_service(
        db,
        identidad.id,
    )

    return [
        Role.from_model(role)
        for role in roles
    ]


def _resolver_list_permissions(info: Info) -> list[Permission]:

    identidad = _identidad(info)

    db = info.context["db"]

    permissions = list_permissions_service(
        db,
        identidad.id,
    )

    return [
        Permission.from_model(permission)
        for permission in permissions
    ]


def _resolver_list_role_permissions(
    info: Info,
    role_id: int,
) -> list[RolePermission]:

    identidad = _identidad(info)

    db = info.context["db"]

    relations = list_role_permissions_service(
        db,
        identidad.id,
        role_id,
    )

    return [
        RolePermission.from_model(relation)
        for relation in relations
    ]


@strawberry.type
class Query:

    @strawberry.field
    def accounts(
        self,
        info: Info,
        company_id: int,
        account_type: AccountType | None = None,
        active_only: bool = True,
    ) -> list[Account]:

        identidad = _identidad(info)

        db = info.context["db"]

        accounts = list_accounts_service(
            db,
            identidad.id,
            company_id=company_id,
            account_type=(
                AccountTypeModel(account_type.value)
                if account_type
                else None
            ),
            active_only=active_only,
        )

        return [
            Account.from_model(account)
            for account in accounts
        ]

    @strawberry.field
    def company_users(
        self,
        info: Info,
        company_id: int,
        active_only: bool = True,
    ) -> list[CompanyUser]:

        identidad = _identidad(info)

        db = info.context["db"]

        memberships = list_company_users_service(
            db,
            identidad.id,
            company_id=company_id,
            active_only=active_only,
        )

        return [
            CompanyUser.from_model(membership)
            for membership in memberships
        ]

    @strawberry.field
    def account(
        self,
        info: Info,
        account_id: int,
    ) -> Account:

        identidad = _identidad(info)

        db = info.context["db"]

        account = get_account_service(
            db,
            identidad.id,
            account_id,
        )

        return Account.from_model(account)

    @strawberry.field
    def concepts(
        self,
        info: Info,
        company_id: int,
        concept_type: ConceptType | None = None,
        active_only: bool = True,
    ) -> list[Concept]:

        identidad = _identidad(info)

        db = info.context["db"]

        concepts = list_concepts_service(
            db,
            identidad.id,
            company_id=company_id,
            concept_type=(
                ConceptTypeModel(concept_type.value)
                if concept_type
                else None
            ),
            active_only=active_only,
        )

        return [
            Concept.from_model(concept)
            for concept in concepts
        ]

    @strawberry.field
    def concept(
        self,
        info: Info,
        concept_id: int,
    ) -> Concept:

        identidad = _identidad(info)

        db = info.context["db"]

        concept = get_concept_service(
            db,
            identidad.id,
            concept_id,
        )

        return Concept.from_model(concept)

    @strawberry.field
    def account_concepts(
        self,
        info: Info,
        account_id: int,
    ) -> list[AccountConcept]:

        identidad = _identidad(info)

        db = info.context["db"]

        relations = get_account_concepts_service(
            db,
            identidad.id,
            account_id,
        )

        return [
            AccountConcept.from_model(relation)
            for relation in relations
        ]

    @strawberry.field
    def transactions(
        self,
        info: Info,
        account_id: int,
        transaction_type: TransactionType | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Transaction]:

        identidad = _identidad(info)

        db = info.context["db"]

        transactions = list_transactions_service(
            db,
            identidad.id,
            account_id=account_id,
            transaction_type=(
                TransactionTypeModel(transaction_type.value)
                if transaction_type
                else None
            ),
            limit=limit,
            offset=offset,
        )

        return [
            Transaction.from_model(transaction)
            for transaction in transactions
        ]

    @strawberry.field
    def account_balance(
        self,
        info: Info,
        account_id: strawberry.ID,
        from_date: date,
        to_date: date,
    ) -> AccountBalance:

        identidad = _identidad(info)

        db = info.context["db"]

        balance = account_balance_service(
            db,
            identidad.id,
            _a_entero(account_id, "accountId"),
            from_date,
            to_date,
        )

        return AccountBalance.from_result(balance)

    @strawberry.field
    def general_balance(
        self,
        info: Info,
        from_date: date,
        to_date: date,
    ) -> GeneralBalance:

        identidad = _identidad(info)

        db = info.context["db"]

        balance = general_balance_service(
            db,
            identidad.id,
            identidad.company_id,
            from_date,
            to_date,
        )

        return GeneralBalance.from_result(balance)

    @strawberry.field
    def list_roles(
        self,
        info: Info,
    ) -> list[Role]:

        return _resolver_list_roles(info)

    @strawberry.field
    def roles(
        self,
        info: Info,
    ) -> list[Role]:
        """Alias (Actividad 4) de listRoles; delega en la misma logica."""

        return _resolver_list_roles(info)

    @strawberry.field
    def list_permissions(
        self,
        info: Info,
    ) -> list[Permission]:

        return _resolver_list_permissions(info)

    @strawberry.field
    def permissions(
        self,
        info: Info,
    ) -> list[Permission]:
        """Alias (Actividad 4) de listPermissions; delega en la misma logica."""

        return _resolver_list_permissions(info)

    @strawberry.field
    def list_role_permissions(
        self,
        info: Info,
        role_id: int,
    ) -> list[RolePermission]:

        return _resolver_list_role_permissions(
            info,
            role_id,
        )

    @strawberry.field
    def role_permissions(
        self,
        info: Info,
        role_id: int,
    ) -> list[RolePermission]:
        """Alias (Actividad 4) de listRolePermissions(roleId:); delega en
        la misma logica."""

        return _resolver_list_role_permissions(
            info,
            role_id,
        )

    @strawberry.field
    def permission_catalog(
        self,
        info: Info,
        resource: PermissionResource | None = None,
    ) -> list[Permission]:
        """Catalogo de permisos activos, filtrable por recurso."""

        identidad = _identidad(info)

        prefijo = (
            PREFIJOS_RECURSO.get(resource) if resource is not None else None
        )

        db = info.context["db"]

        permisos = permission_catalog_service(
            db,
            identidad.id,
            prefix=prefijo,
        )

        return [
            Permission.from_model(permission)
            for permission in permisos
        ]

    @strawberry.field
    def preview_role_permissions(
        self,
        info: Info,
        input: SetRolePermissionsInput,
    ) -> RolePermissionPlan | None:
        """Previsualizacion de la lista completa de permisos de un rol.
        Solo lectura: no modifica relaciones."""

        identidad = _identidad(info)

        role_id = _a_entero(input.role_id, "roleId")

        db = info.context["db"]

        plan = preview_role_permissions_service(
            db,
            identidad.id,
            role_id,
            input.permission_ids,
        )

        role = plan["role"]

        return RolePermissionPlan(
            role=Role.from_model(role),
            current=[
                Permission.from_model(permission)
                for permission in plan["current"]
            ],
            to_activate=[
                Permission.from_model(permission)
                for permission in plan["to_activate"]
            ],
            to_deactivate=[
                Permission.from_model(permission)
                for permission in plan["to_deactivate"]
            ],
            unchanged=[
                Permission.from_model(permission)
                for permission in plan["unchanged"]
            ],
            final_count=plan["final_count"],
        )


@strawberry.type
class Mutation:

    @strawberry.mutation
    def login(
        self,
        info: Info,
        input: LoginInput,
    ) -> AuthPayload:

        db = info.context["db"]

        token, usuario = authenticate_user(
            db,
            input.email,
            input.password,
        )

        return AuthPayload(
            token=token,
            token_type="bearer",
            user=User.from_model(usuario),
        )

    @strawberry.mutation
    def create_account(
        self,
        info: Info,
        input: CreateAccountInput,
    ) -> Account:

        identidad = _identidad(info)

        db = info.context["db"]

        account = create_account_service(
            db,
            identidad.id,
            company_id=input.company_id,
            account_type=AccountTypeModel(
                input.account_type.value
            ),
            name=input.name,
            bank_name=input.bank_name,
            account_number=input.account_number,
            clabe=input.clabe,
            card_last_digits=input.card_last_digits,
            short_description=input.short_description,
            long_description=input.long_description,
        )

        return Account.from_model(account)

    @strawberry.mutation
    def create_concept(
        self,
        info: Info,
        input: CreateConceptInput,
    ) -> Concept:

        identidad = _identidad(info)

        db = info.context["db"]

        concept = create_concept_service(
            db,
            identidad.id,
            company_id=input.company_id,
            concept_type=ConceptTypeModel(
                input.concept_type.value
            ),
            name=input.name,
            short_description=input.short_description,
            long_description=input.long_description,
        )

        return Concept.from_model(concept)

    @strawberry.mutation
    def assign_concept_to_account(
        self,
        info: Info,
        input: AssignConceptToAccountInput,
    ) -> AccountConcept:

        identidad = _identidad(info)

        db = info.context["db"]

        relation = assign_concept_to_account(
            db,
            identidad.id,
            account_id=input.account_id,
            concept_id=input.concept_id,
        )

        return AccountConcept.from_model(relation)

    @strawberry.mutation
    def remove_concept_from_account(
        self,
        info: Info,
        account_id: int,
        concept_id: int,
    ) -> AccountConcept:

        identidad = _identidad(info)

        db = info.context["db"]

        relation = remove_concept_from_account(
            db,
            identidad.id,
            account_id=account_id,
            concept_id=concept_id,
        )

        return AccountConcept.from_model(relation)

    @strawberry.mutation
    def create_transaction(
        self,
        info: Info,
        input: CreateTransactionInput,
    ) -> Transaction:

        identidad = _identidad(info)

        db = info.context["db"]

        transaction = create_transaction_service(
            db,
            identidad.id,
            account_id=input.account_id,
            concept_id=input.concept_id,
            transaction_type=TransactionTypeModel(
                input.transaction_type.value
            ),
            amount=input.amount,
            captured_by=identidad.user_id,
            transaction_date=input.transaction_date,
            short_description=input.short_description,
            long_description=input.long_description,
        )

        return Transaction.from_model(transaction)

    @strawberry.mutation
    def delete_transaction(
        self,
        info: Info,
        transaction_id: int,
    ) -> Transaction:

        identidad = _identidad(info)

        db = info.context["db"]

        transaction = delete_transaction_service(
            db,
            identidad.id,
            transaction_id,
        )

        return Transaction.from_model(transaction)

    @strawberry.mutation
    def create_role(
        self,
        info: Info,
        input: CreateRoleInput,
    ) -> Role:

        identidad = _identidad(info)

        db = info.context["db"]

        role = create_role_service(
            db,
            identidad.id,
            code=input.code,
            name=input.name,
            description=input.description,
        )

        return Role.from_model(role)

    @strawberry.mutation
    def deactivate_role(
        self,
        info: Info,
        role_id: int,
    ) -> Role:

        identidad = _identidad(info)

        db = info.context["db"]

        role = deactivate_role_service(
            db,
            identidad.id,
            role_id,
        )

        return Role.from_model(role)

    @strawberry.mutation
    def create_permission(
        self,
        info: Info,
        input: CreatePermissionInput,
    ) -> Permission:

        identidad = _identidad(info)

        db = info.context["db"]

        permission = create_permission_service(
            db,
            identidad.id,
            code=input.code,
            name=input.name,
            description=input.description,
        )

        return Permission.from_model(permission)

    @strawberry.mutation
    def assign_permission_to_role(
        self,
        info: Info,
        input: AssignPermissionToRoleInput,
    ) -> RolePermission:

        identidad = _identidad(info)

        db = info.context["db"]

        relation = assign_permission_to_role_service(
            db,
            identidad.id,
            role_id=input.role_id,
            permission_id=input.permission_id,
        )

        return RolePermission.from_model(relation)

    @strawberry.mutation
    def remove_permission_from_role(
        self,
        info: Info,
        role_id: int,
        permission_id: int,
    ) -> RolePermission:

        identidad = _identidad(info)

        db = info.context["db"]

        relation = remove_permission_from_role_service(
            db,
            identidad.id,
            role_id,
            permission_id,
        )

        return RolePermission.from_model(relation)

    @strawberry.mutation
    def set_role_permissions(
        self,
        info: Info,
        input: SetRolePermissionsInput,
    ) -> RolePermissionUpdate | None:
        """Establece exactamente la lista de permisos activos de un rol
        en una unica transaccion con un unico commit."""

        identidad = _identidad(info)

        role_id = _a_entero(input.role_id, "roleId")

        db = info.context["db"]

        resumen = set_role_permissions_service(
            db,
            identidad.id,
            role_id,
            input.permission_ids,
        )

        role = resumen["role"]

        return RolePermissionUpdate(
            role=Role.from_model(role),
            activated=[
                Permission.from_model(permission)
                for permission in resumen["activated"]
            ],
            deactivated=[
                Permission.from_model(permission)
                for permission in resumen["deactivated"]
            ],
            unchanged=[
                Permission.from_model(permission)
                for permission in resumen["unchanged"]
            ],
            final_count=resumen["final_count"],
            changed=resumen["changed"],
        )

    @strawberry.mutation
    def create_company_user(
        self,
        info: Info,
        input: CreateCompanyUserInput,
    ) -> CompanyUser:

        identidad = _identidad(info)

        db = info.context["db"]

        company_user = create_company_user_service(
            db,
            identidad.id,
            company_id=input.company_id,
            user_id=input.user_id,
            is_admin=input.is_admin,
        )

        return CompanyUser.from_model(company_user)

    @strawberry.mutation
    def deactivate_company_user(
        self,
        info: Info,
        company_user_id: int,
    ) -> CompanyUser:

        identidad = _identidad(info)

        db = info.context["db"]

        company_user = deactivate_company_user_service(
            db,
            identidad.id,
            company_user_id,
        )

        return CompanyUser.from_model(company_user)

    @strawberry.mutation
    def assign_role(
        self,
        info: Info,
        input: AssignRoleInput,
    ) -> CompanyUserRole:

        identidad = _identidad(info)

        db = info.context["db"]

        relation = assign_role_service(
            db,
            identidad.id,
            company_user_id=input.company_user_id,
            role_id=input.role_id,
        )

        return CompanyUserRole.from_model(relation)


schema = strawberry.Schema(
    query=Query,
    mutation=Mutation,
)